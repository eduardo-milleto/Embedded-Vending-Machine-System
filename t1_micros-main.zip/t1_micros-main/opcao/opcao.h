#ifndef OPCAO_H_
#define OPCAO_H_

void requestProductCode();
void displayProductInfo(const char* productCode);
void selectPaymentMethod(void);

#endif /* OPCAO_H_ */
