#ifndef DINHEIRO_H
#define DINHEIRO_H

void handleCashPayment();

#endif // DINHEIRO_H
